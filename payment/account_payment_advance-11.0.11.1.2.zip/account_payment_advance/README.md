# account_payment_advances
This module allows the user to select an account before entering a payment.


Odoo - Account Payment Advance
=============================
This module allows the user to select an account before entering a payment.


## Credits
<p>
<img width="200" alt="Logo Konos" src="http://www.konos.cl/web/image/666" />
</p>
**Konos** - http://konos.cl
 - Nelson Ramírez <info@konos.cl>


