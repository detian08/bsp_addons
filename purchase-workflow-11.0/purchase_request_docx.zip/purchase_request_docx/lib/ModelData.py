import jinja2
from docxtpl import DocxTemplate
from . import Formatter


class ModelData:

    def prepare_purchase_request_document(self):
        doc = DocxTemplate("template/purchase_request.docx")
        purchaserequest_data  = self.env['purchase.request'].search([])
        context = purchaserequest_data
        # context.update(partner_data)
        # context.update({'items': saleorder_line_data})
        jinja_env = jinja2.Environment(
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=False
        )
        doc.render(context, jinja_env)
        doc.save("tmp/saleorder.docx")
