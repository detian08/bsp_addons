import base64
import os

try:
    from StringIO import StringIO  ## for Python 2
except ImportError:
    from io import StringIO  ## for Python 3
from docxtpl import DocxTemplate

import datetime
from datetime import datetime
from odoo import api, fields, models


def get_context():
    return {
        'name': 12345,
        'date_start': '10-10-2019',
        'due_date': '30 Apr',
        'name': 'Jane Doe',
        'net_amount_total': 96000000,
        'company': 'BLG',
        'description': 'penggantian dan service rutin',
        'items': [
            {
                'product_name': 'ABCD-01',
                'name': 'Service Ganti Oli',
                'product_qty': 30,
                'product_uom': 'Unit',
                'discount': 10,
                'price_unit': 50000,
                'net_price_subtotal': 1589000
            },
            {
                'product_name': 'ABCD-02',
                'name': 'Spare part',
                'product_qty': 50,
                'product_uom': 'Unit',
                'discount': 10,
                'price_unit': 80000,
                'net_price_subtotal': 1544000
            },
            {
                'product_name': 'ABCD-03',
                'name': 'Service saja',
                'product_qty': 60,
                'product_uom': 'Unit',
                'discount': 15,
                'price_unit': 588000,
                'net_price_subtotal': 17889000
            }
        ]
    }


class PurchaseRequestReportOut(models.Model):
    _name = 'purchase.request.report.docx'
    _description = 'purchase request report'

    purchase_request_data = fields.Char('Name', size=256)
    file_name = fields.Binary('Docx Report', readonly=True)


class WizardPurchaseRequest(models.Model):
    _name = 'wizard.purchase.request.print2'
    _description = "purchase request print wizard"

    @api.multi
    def print_report(self):
        self.ensure_one()
        datadir = os.path.dirname(__file__)
        f = os.path.join(datadir, 'templates\purchase_request.docx')
        template = DocxTemplate(f)
        context = get_context()
        template.render(context)
        filename = ('PurchaseRequestRep-' + str(datetime.today().date()) + '.docx')
        template.save(filename)
        fp = open(filename, "rb")
        file_data = fp.read()
        out = base64.encodestring(file_data)

        attach_vals = {
            'purchase_request_data': filename,
            'file_name': out,
        }

        act_id = self.env['purchase.request.report.docx'].create(attach_vals)
        fp.close()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.request.report.docx',
            'res_id': act_id.id,
            'view_type': 'form',
            'view_mode': 'form',
            'context': self.env.context,
            'target': 'new',
        }
